# Parquet Adapter

- [Parquet Writer](./task1.py)
