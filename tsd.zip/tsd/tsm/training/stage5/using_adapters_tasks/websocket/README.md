# Websocket Adapter

- [Websocket Client](./task1.py)
- [Websocket Output](./task2.py)
