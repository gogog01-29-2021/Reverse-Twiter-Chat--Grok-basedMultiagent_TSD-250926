# Kafka Adapter

- [Kafka Example](./task1.py)
