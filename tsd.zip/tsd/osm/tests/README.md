before test set configuration by osm/README.md first

and...

run test with

```plain
pytest osm/tests/test_order_flow.py -v
```
