TEST_EXCHANGE_ENDPOINTS = {
    "BINANCE": "https://testnet.binance.vision/api/v3/order",
    "BYBIT": "https://api-testnet.bybit.com/v5/order/create",
    "COINBASE": "https://api-public.sandbox.exchange.coinbase.com/orders",
    # Add OKX if needed
}

TEST_EXCHANGE_CREDENTIALS = {
    "BINANCE": {
        "API_KEY": "gaodof9ZIbrXnRgBpfw09Qv7fHFqUgOjV9W0jh2idYWqTA5JK5VS8qfYH5gdlRCL",
        "SECRET": "XKqSJe0XeLcpxRrAdKHSHT9N5YQvVvYuvWdf6VIfChcVglGTjbq3x0jeC7MhmGrK",
    },
    "COINBASE": {
        "API_KEY": "07aad0d29b481f995b951c9b9e115b5a",
        "SECRET": "6IQj5y0CHu3Jk0IXaM+l8p3YNiQm9kDiO+dL9VUvslkmK1EzW/vnYg4VUz2Gch4aZJeWsaLPJ7C02sCWAnSjGw==",
        "PASSPHRASE": "yia1vflt8fge",
    },
}
